/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nl.hva.ict.ds;

import static java.lang.Math.toIntExact;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Hugo
 */
public class BucketSortHighScores implements HighScoreList{
    
    public List<Player> players = new ArrayList<>();


    @Override
    public void add(Player player) {
        players.add(player);
    }

    @Override
    public List<Player> getHighScores(int numberOfHighScores) {
        
        List<Player> bucket = new ArrayList<>();
        Bucket[] buckets = new Bucket[numberOfHighScores];
        for(int i = 0; i < numberOfHighScores; i++){
            buckets[i] = new Bucket();
        }
        for(int i = 0; i < buckets.length; i++){
            buckets[i] = players.get(i).getHighScore();
        }
        
        
        
        
        
//        ArrayList<Integer> bucket = new ArrayList<>();
//        Bucket[] buckets = new Bucket[numberOfHighScores];
//        for(int i = 0; i < numberOfHighScores; i++){
//            buckets[i] = new Bucket();
//        }
//        
//        for(Player n: players){
//            long bucketIndex1 = n.getHighScore()*buckets.length/numberOfHighScores;
//            int bucketIndex2 = toIntExact(bucketIndex1);
//            int highscore = toIntExact(n.getHighScore());
//            buckets[bucketIndex2].bucket.add(highscore);
//        }
//        
//        for(Bucket n: buckets){
//            for (int i = 1; i < players.size(); i++) {
//            Player playerToSort = players.get(n.bucket.indexOf(i)); //pakt de geselecteerde speler en maakt er een tijdelijk object van
//            Integer j = i; //kopieert i
//            while (j > 0 && players.get(j-1).getHighScore() > playerToSort.getHighScore()) { //loopt tot dat de highscore voor de geselecteerde speler groter is
//                players.set(j, players.get(j-1)); //verandert de waarde naar degene daarvoor
//                j--;
//            }
//            players.set(j, playerToSort); //zet de tijdelijke waarde weer op de goede plek
//            
//        }
//        }
//        
//        for(int i = 0; i < bucket.size(); i++){
//        System.out.println(bucket.get(i));
//        }
//        
//        //for(int player)
    
    }

    @Override
    public List<Player> findPlayer(String firstName, String lastName) {
        List<Player> matchedPlayers = new ArrayList<>();
        for (Player player : players) {
            if (player.getFirstName().equals(firstName)) {
                matchedPlayers.add(player);
            }
        }
        return matchedPlayers;
    }
    
}

class Bucket {
    ArrayList<Integer> bucket = new ArrayList<>();
}
